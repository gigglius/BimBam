package com.gigglius.robloxvr;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Pixel-faithful launcher recreation of the supplied 2014 Roblox mobile
 * dashboard captures. The reference captures are kept at their native
 * 2532x1170 aspect ratio and displayed edge-to-edge; transparent hit areas
 * make the classic tiles navigable without changing their appearance.
 */
public class MainActivity extends Activity {
    private FrameLayout root;
    private ImageView referenceScreen;
    private int menuPage = 0;
    private float downX, downY;

    private static final String[][] PAGE_ONE = {
        {"Games", "Catalog", "Inventory", "Builders Club"}
    };
    private static final String[][] PAGE_TWO = {
        {"Profile", "Messages", "Groups", "Leaderboards"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        showMenu();
    }

    private void showMenu() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        referenceScreen = new ImageView(this);
        referenceScreen.setImageResource(menuPage == 0
                ? R.drawable.roblox_2014_dashboard_1
                : R.drawable.roblox_2014_dashboard_2);
        referenceScreen.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(referenceScreen, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.post(() -> addHitTargets());
        root.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                downX = event.getX(); downY = event.getY(); return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float dx = event.getX() - downX;
                float dy = event.getY() - downY;
                if (Math.abs(dx) > root.getWidth() * .12f && Math.abs(dx) > Math.abs(dy)) {
                    menuPage = dx < 0 ? 1 : 0;
                    showMenu();
                }
                return true;
            }
            return true;
        });
    }

    private void addHitTargets() {
        if (root == null) return;
        String[] labels = menuPage == 0 ? PAGE_ONE[0] : PAGE_TWO[0];
        // Fractions are measured against the original 2532x1170 reference.
        float[][] cards = {
            {.366f, .030f, .615f, .510f},
            {.680f, .030f, .930f, .510f},
            {.366f, .550f, .615f, .995f},
            {.680f, .550f, .930f, .995f}
        };
        for (int i = 0; i < cards.length; i++) {
            final String label = labels[i];
            float[] r = cards[i];
            View hit = new View(this);
            hit.setBackgroundColor(Color.TRANSPARENT);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    Math.round((r[2] - r[0]) * root.getWidth()),
                    Math.round((r[3] - r[1]) * root.getHeight()));
            lp.leftMargin = Math.round(r[0] * root.getWidth());
            lp.topMargin = Math.round(r[1] * root.getHeight());
            root.addView(hit, lp);
            hit.setOnClickListener(v -> showSection(label));
        }
        // The small circular information control in the lower-right corner.
        View info = new View(this);
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(
                Math.round(root.getWidth() * .055f), Math.round(root.getHeight() * .16f),
                Gravity.RIGHT | Gravity.BOTTOM);
        root.addView(info, infoLp);
        info.setOnClickListener(v -> showSection("About ROBLOX"));
    }

    private void showSection(String name) {
        FrameLayout panel = new FrameLayout(this);
        panel.setBackgroundColor(0xE610294B);
        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new FrameLayout.LayoutParams(-1, -1));
        TextView back = new TextView(this);
        back.setText("‹  BACK");
        back.setTextColor(Color.WHITE);
        back.setTextSize(17);
        back.setPadding(28, 18, 28, 18);
        FrameLayout.LayoutParams backLp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.LEFT);
        panel.addView(back, backLp);
        back.setOnClickListener(v -> showMenu());
        panel.setOnClickListener(v -> { /* keep section open; use BACK to return */ });
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
    }

    @Override public void onBackPressed() {
        showMenu();
    }
}
